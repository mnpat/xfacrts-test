import boto3
import json
import zipfile


def lambda_handler(event, context):
    clients = boto3.client("events")
    s3 = boto3.client('s3')
    code_pipeline = boto3.client('codepipeline')
    
    print("Event: ", event)
    
    bucket_name = event['CodePipeline.job']['data']['inputArtifacts'][0]['location']['s3Location']['bucketName']
    object_path_key = event['CodePipeline.job']['data']['inputArtifacts'][0]['location']['s3Location']['objectKey']
    job_id = event['CodePipeline.job']['id']
    revision = event['CodePipeline.job']['data']['inputArtifacts'][0]['revision']
    s3_artifact_path = f's3://{bucket_name}/{object_path_key}'

    path = {"bucket": bucket_name,"key": object_path_key}
    s3_artifact_path = json.dumps(path)
        

    response = clients.put_events(
        Entries=[
            {
                
                'Source': 'xfactrs-sagemaker-lambda-events',
                
                'DetailType': 'sagemaker-PipelineType',
                
                'Detail': s3_artifact_path,

                'EventBusName': 'default'
            }
        ]
        
    )
    
    print("response from eventbridge put_event: ", response)
    
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
    
        code_pipeline.put_job_success_result(jobId=job_id)
    else:
        response = client.put_job_failure_result(
        jobId=job_id,
        failureDetails={
            'type': 'JobFailed',
            'message': 'Lambda failed'
            }
        )
    

    return response